# Personal website for Quelle F. Laurente

This repository hosts my personal website using GitHub Pages.
Added two sample JavaScript projects: Taskify (To‑Do app) and WeatherNow (weather dashboard).

## Published at
https://qflaurente28.github.io/

## Files
- index.html
- assets/styles.css
- assets/script.js

© 2025 Quelle F. Laurente
