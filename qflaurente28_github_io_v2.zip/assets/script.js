document.addEventListener('DOMContentLoaded',()=>{
  document.getElementById('year').textContent = new Date().getFullYear();
});

function openDemo(name){
  const demos = document.getElementById('demos');
  demos.innerHTML = '';
  if(name === 'taskify'){
    demos.innerHTML = `
      <h3 id="taskify-demo">Taskify — Demo</h3>
      <p>Simple To‑Do app (local). Try adding a task below.</p>
      <div style="margin-bottom:8px;">
        <input id="task-input" placeholder="New task" style="padding:8px; width:60%"/>
        <button id="add-task" style="padding:8px">Add</button>
      </div>
      <ul id="task-list" style="list-style:none; padding-left:0;"></ul>
      <small>Tasks are stored in your browser's localStorage.</small>
    `;
    initTaskify();
  } else if(name === 'weathernow'){
    demos.innerHTML = `
      <h3 id="weathernow-demo">WeatherNow — Demo (preview)</h3>
      <p>Enter any city to see a mock weather response (no API key required for demo).</p>
      <div style="margin-bottom:8px;">
        <input id="city-input" placeholder="City name" style="padding:8px; width:60%"/>
        <button id="get-weather" style="padding:8px">Get</button>
      </div>
      <div id="weather-result"></div>
    `;
    initWeatherNow();
  }
}

function initTaskify(){
  const input = document.getElementById('task-input');
  const btn = document.getElementById('add-task');
  const list = document.getElementById('task-list');
  const STORAGE_KEY = 'qf_taskify_tasks';
  const tasks = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');

  function render(){
    list.innerHTML = '';
    tasks.forEach((t, i) => {
      const li = document.createElement('li');
      li.style.padding = '8px 0';
      li.innerHTML = \`<label style="display:flex; gap:8px; align-items:center"><input type="checkbox"\${t.done ? ' checked' : ''} data-i="\${i}"/><span style="flex:1; text-decoration:\${t.done?'line-through':''}">\${t.text}</span><button data-del="\${i}" style="margin-left:8px">Delete</button></label>\`;
      list.appendChild(li);
    });
  }

  function save(){ localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks)); }

  list.addEventListener('click', (e) => {
    if(e.target.matches('[data-del]')){
      const i = Number(e.target.getAttribute('data-del'));
      tasks.splice(i,1); save(); render();
    }
    if(e.target.type === 'checkbox'){
      const i = Number(e.target.getAttribute('data-i'));
      tasks[i].done = e.target.checked; save(); render();
    }
  });

  btn.addEventListener('click', () => {
    const v = input.value.trim(); if(!v) return;
    tasks.push({text:v, done:false}); input.value=''; save(); render();
  });

  render();
}

function initWeatherNow(){
  const input = document.getElementById('city-input');
  const btn = document.getElementById('get-weather');
  const out = document.getElementById('weather-result');

  btn.addEventListener('click', () => {
    const city = input.value.trim();
    if(!city){ out.innerHTML = '<p>Please enter a city name.</p>'; return; }
    // Mock response for demo (replace this with real fetch + API key in your repo)
    const mock = {
      name: city,
      temp: (20 + Math.floor(Math.random()*15)) + '°C',
      humidity: (40 + Math.floor(Math.random()*50)) + '%',
      desc: ['Clear sky','Partly cloudy','Light rain'][Math.floor(Math.random()*3)]
    };
    out.innerHTML = `<h4>\${mock.name}</h4><p>\${mock.desc} • \${mock.temp} • Humidity: \${mock.humidity}</p><p><em>(This is a demo mock — connect to an API in your repo.)</em></p>`;
  });
}